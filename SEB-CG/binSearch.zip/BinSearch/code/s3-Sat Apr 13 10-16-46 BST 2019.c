//this is some text to be inserted
int r;
int k;
int i;
int j;
int binSearch(int f, int z, int v)
{
    //INITIALISATION
    r = 0;
    k = ((z - 1) / 2);
    i = 0;
    j = z;
  while(f[k] != v)
  {
        if(f[k] < v)
        {
            //search_inc
            i = (k + 1);
            k = (((k + j) + 1) / 2);
        }
        else
        {
            //search_dec
            j = (k - 1);
            k = (((i + k) - 1) / 2);
        }
  }
    //found
    r = k;

return r;
}

